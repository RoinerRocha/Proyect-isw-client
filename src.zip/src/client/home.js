import axios from "axios";
import { useEffect, useState } from "react";
import Header from "./header";
import{useNavigate} from "react-router"

function Home() {
    fetch("http://localhost:5000/userData",{
        method: "POST",
        headers: {
            "Content-Type":"application/json",
        },
        body: JSON.stringify({
            token: window.localStorage.getItem("Token"),
        }),
    })
    .then((res) => res.json())
    .then((data)=> {
        console.log(data, "userData");
    });
    /*const navigate=useNavigate();
    let personaDb = JSON.parse(sessionStorage.getItem('Token'));//valida si la persona esta logueada si no lo devuelve al registro
    console.log(personaDb)
    let nomp="null";
    if(!personaDb){
        navigate("/")
        alert("No estas logueado");
    }else{
      nomp=personaDb.lname;
    }*/
    return(
        <div className="b">
             {<Header />}
        </div>
    )
}
export default Home;